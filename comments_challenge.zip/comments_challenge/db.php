<?php

// Gegevens om verbinding te maken met MySQL
$host = 'localhost';
$port = '8889';
$dbname = 'comments_challenge';
$username = 'root';
$password = 'root';

try {

    // Verbinding maken met de database via PDO
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );

    // PDO geeft een foutmelding als er iets misgaat
    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch (PDOException $e) {

    // Programma stoppen als de databaseverbinding mislukt
    die('Databaseverbinding mislukt: ' . $e->getMessage());
}