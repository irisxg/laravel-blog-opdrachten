<?php

// Verbinding met de database maken
require 'db.php';

// Composer laden voor Carbon
require 'vendor/autoload.php';

use Carbon\Carbon;


// -------------------------
// 1. Variabelen
// -------------------------

$errors = [];

$name = '';
$email = '';
$comment = '';


// -------------------------
// 2. Formulier verwerken
// -------------------------

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Gegevens uit het formulier ophalen
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $comment = trim($_POST['comment'] ?? '');


    // Naam controleren
    if ($name === '') {
        $errors['name'] = 'Vul je naam in.';
    }


    // E-mail controleren
    if ($email === '') {

        $errors['email'] = 'Vul je e-mailadres in.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        // Server-side controle of het e-mailadres geldig is
        $errors['email'] = 'Vul een geldig e-mailadres in.';
    }


    // Comment controleren
    if ($comment === '') {

        $errors['comment'] = 'Vul een comment in.';

    } elseif (strlen($comment) > 1000) {

        $errors['comment'] = 'Je comment mag maximaal 1000 tekens bevatten.';
    }


    // Als er geen fouten zijn, opslaan in de database
    if (empty($errors)) {

        $sql = "
            INSERT INTO comments (name, email, comment)
            VALUES (:name, :email, :comment)
        ";

        // Prepared statement gebruiken
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':comment' => $comment
        ]);


        // Terug naar de pagina na het opslaan
        header('Location: index.php');
        exit;
    }
}


// -------------------------
// 3. Comments uit database ophalen
// -------------------------

$stmt = $pdo->query("
    SELECT id, name, email, comment, created_at
    FROM comments
    ORDER BY created_at DESC
");

$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="nl">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Video & Comments</title>


    <style>

        /* Algemene instellingen */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f3f3f3;
            margin: 0;
            padding: 40px 20px;
        }


        /* Hoofdcontainer */
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
        }


        /* YouTube-video */
        iframe {
            width: 100%;
            height: 500px;
            display: block;
            border: none;
            border-radius: 8px;
        }


        /* Formulier */
        form {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 20px;
        }


        /* Inputvelden */
        input,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }


        textarea {
            resize: vertical;
        }


        /* Knop */
        button {
            margin-top: 10px;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #222;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }


        button:hover {
            background: #444;
        }


        /* Foutmeldingen */
        .error {
            color: red;
            margin: 0 0 10px 0;
        }


        /* Een comment */
        .comment {
            border-bottom: 1px solid #ddd;
            padding: 20px 0;
        }


        .comment:last-child {
            border-bottom: none;
        }


        .comment-name {
            margin: 0;
        }


        .comment-date {
            color: #777;
            font-size: 14px;
            margin-top: 5px;
        }


        .comment-text {
            line-height: 1.6;
        }

    </style>

</head>


<body>

<main class="container">


    <!-- Titel -->
    <h1>Mijn video</h1>


    <!-- YouTube-video -->
    <iframe
        src="https://www.youtube.com/embed/dQw4w9WgXcQ"
        title="YouTube video"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen>
    </iframe>


    <!-- Comment formulier -->
    <h2>Laat een reactie achter</h2>


    <form method="POST" action="">


        <!-- Naam -->
        <label for="name">Naam</label>

        <input
            type="text"
            id="name"
            name="name"
            value="<?= htmlspecialchars($name) ?>"
        >

        <?php if (isset($errors['name'])): ?>

            <p class="error">
                <?= htmlspecialchars($errors['name']) ?>
            </p>

        <?php endif; ?>


        <!-- E-mail -->
        <label for="email">E-mail</label>

        <input
            type="email"
            id="email"
            name="email"
            value="<?= htmlspecialchars($email) ?>"
        >

        <?php if (isset($errors['email'])): ?>

            <p class="error">
                <?= htmlspecialchars($errors['email']) ?>
            </p>

        <?php endif; ?>


        <!-- Comment -->
        <label for="comment">Comment</label>

        <textarea
            id="comment"
            name="comment"
            rows="5"
        ><?= htmlspecialchars($comment) ?></textarea>

        <?php if (isset($errors['comment'])): ?>

            <p class="error">
                <?= htmlspecialchars($errors['comment']) ?>
            </p>

        <?php endif; ?>


        <!-- Versturen -->
        <button type="submit">
            Plaats comment
        </button>

    </form>


    <!-- Alle comments -->
    <h2>Comments</h2>


    <?php if (empty($comments)): ?>

        <p>Er zijn nog geen comments.</p>

    <?php else: ?>


        <?php foreach ($comments as $commentItem): ?>

            <article class="comment">


                <!-- Naam van de persoon -->
                <h3 class="comment-name">
                    <?= htmlspecialchars($commentItem['name']) ?>
                </h3>


                <!-- Hoe lang geleden -->
                <p class="comment-date">

                    <?= Carbon::parse($commentItem['created_at'])->diffForHumans() ?>

                </p>


                <!-- Comment -->
                <p class="comment-text">

                    <?= nl2br(htmlspecialchars($commentItem['comment'])) ?>

                </p>


            </article>

        <?php endforeach; ?>


    <?php endif; ?>


</main>

</body>

</html>