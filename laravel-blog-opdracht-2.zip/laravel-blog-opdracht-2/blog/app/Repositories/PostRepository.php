<?php

namespace App\Repositories;

use App\Models\Post;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Cache;

class PostRepository
{
    public function all(?string $search = null): Collection
    {
        if ($search) {
            return Post::query()
                ->where('title', 'like', "%{$search}%")
                ->orWhere('excerpt', 'like', "%{$search}%")
                ->orWhere('body', 'like', "%{$search}%")
                ->latest('published_at')
                ->get();
        }

        return Cache::remember(
            'posts.all',
            now()->addMinutes(10),
            fn () => Post::query()->latest('published_at')->get()
        );
    }

    public function findBySlug(string $slug): ?Post
    {
        return Cache::remember(
            "post.{$slug}",
            now()->addMinutes(10),
            fn () => Post::where('slug', $slug)->first()
        );
    }

    public function clearCache(): void
    {
        Cache::forget('posts.all');

        foreach (Post::query()->pluck('slug') as $slug) {
            Cache::forget("post.{$slug}");
        }
    }
}
