<?php

namespace App\Services;

use App\Models\Post;
use App\Repositories\PostRepository;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class PostService
{
    public function __construct(private PostRepository $posts)
    {
    }

    public function getPosts(?string $search = null): Collection
    {
        return $this->posts->all($search);
    }

    public function getPost(string $slug): Post
    {
        $post = $this->posts->findBySlug($slug);

        if (!$post) {
            throw (new ModelNotFoundException)->setModel(Post::class, [$slug]);
        }

        return $post;
    }
}
