<?php

namespace App\Http\Controllers;

use App\Services\PostService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PostController extends Controller
{
    public function __construct(private PostService $postService)
    {
    }

    public function index(Request $request): View
    {
        $posts = $this->postService->getPosts($request->string('search')->toString() ?: null);

        return view('home', compact('posts'));
    }

    public function show(string $slug): View
    {
        $post = $this->postService->getPost($slug);

        return view('post', compact('post'));
    }
}
