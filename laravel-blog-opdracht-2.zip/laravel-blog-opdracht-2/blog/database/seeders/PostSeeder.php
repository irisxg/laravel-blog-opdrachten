<?php

namespace Database\Seeders;

use App\Models\Post;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class PostSeeder extends Seeder
{
    public function run(): void
    {
        $posts = [
            ['image' => 'illustration-1.png'],
            ['image' => 'illustration-2.png'],
            ['image' => 'illustration-3.png'],
            ['image' => 'illustration-4.png'],
            ['image' => 'illustration-5.png'],
        ];

        foreach ($posts as $index => $data) {
            $title = $index === 0
                ? 'This is a big title and it will look great on two or even three lines. Wooohoo!'
                : 'Laravel From Scratch: another useful update for your project.';

            $body = <<<'TEXT'
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.
TEXT;

            $slug = Str::slug($title) . '-' . ($index + 1);

            Post::updateOrCreate(
                ['slug' => $slug],
                [
                    'title' => $title,
                    'slug' => $slug,
                    'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'body' => $body,
                    'image' => $data['image'],
                    'category' => 'Techniques',
                    'secondary_category' => 'Updates',
                    'author_name' => 'Lary Laracore',
                    'author_role' => 'Mascot at Laracasts',
                    'published_at' => now()->subDays(max(1, $index)),
                ]
            );
        }

        Cache::forget('posts.all');
    }
}
