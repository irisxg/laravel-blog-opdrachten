<article class="transition-colors duration-300 hover:bg-gray-100 border border-black border-opacity-0 hover:border-opacity-5 rounded-xl">

    <div class="py-6 px-5 {{ $featured ? 'lg:flex' : '' }}">

        <div class="flex-1 {{ $featured ? 'lg:mr-8' : '' }}">
            <img
                src="{{ asset('images/' . $post->image) }}"
                alt="{{ $post->title }}"
                class="rounded-xl"
            >
        </div>

        <div class="flex-1 flex flex-col justify-between {{ $featured ? 'mt-8 lg:mt-0' : 'mt-8' }}">

            <header>

                <div class="space-x-2">

                    @foreach(explode(',', $post->tags ?? '') as $tag)

                        <span
                            class="px-3 py-1 border rounded-full text-xs uppercase font-semibold
                            {{ $loop->first
                                ? 'border-blue-300 text-blue-300'
                                : 'border-red-300 text-red-300' }}"
                            style="font-size: 10px"
                        >
                            {{ trim($tag) }}
                        </span>

                    @endforeach

                </div>

                <div class="mt-4">

                    <h1 class="text-3xl">
                        {{ $post->title }}
                    </h1>

                    <span class="mt-2 block text-gray-400 text-xs">
                        Published
                        <time>
                            {{ $post->published_at?->diffForHumans() }}
                        </time>
                    </span>

                </div>

            </header>

            <div class="text-sm mt-4">

                <p>
                    {{ $post->excerpt }}
                </p>

            </div>

            <footer class="flex justify-between items-center mt-8">

                <div class="flex items-center text-sm">

                    <img
                        src="{{ asset('images/lary-avatar.svg') }}"
                        alt="Lary avatar"
                    >

                    <div class="ml-3">

                        <h5 class="font-bold">
                            {{ $post->author }}
                        </h5>

                        <h6>
                            Mascot at Laracasts
                        </h6>

                    </div>

                </div>

                <div class="{{ $featured ? 'hidden lg:block' : '' }}">

                    <a
                        href="{{ route('post', $post->slug) }}"
                        class="transition-colors duration-300 text-xs font-semibold bg-gray-200 hover:bg-gray-300 rounded-full py-2 px-8"
                    >
                        Read More
                    </a>

                </div>

            </footer>

        </div>

    </div>

</article>