@extends('layouts.app')

@section('content')
<header class="max-w-xl mx-auto mt-20 text-center">
    <h1 class="text-4xl">
        Latest <span class="text-blue-500">Laravel From Scratch</span> News
    </h1>

    <h2 class="inline-flex mt-2">By Lary Laracore
        <img src="{{ asset('images/lary-head.svg') }}" alt="Head of Lary the mascot">
    </h2>

    <p class="text-sm mt-14">
        Another year. Another update. We're refreshing the popular Laravel series with new content.
        I'm going to keep you guys up to speed with what's going on!
    </p>

    <div class="mt-8">
        <div class="relative flex lg:inline-flex items-center bg-gray-100 rounded-xl px-3 py-2">
            <form method="GET" action="{{ route('home') }}">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Find something"
                       class="bg-transparent placeholder-black font-semibold text-sm focus:outline-none">
            </form>
        </div>
    </div>
</header>

<main class="max-w-6xl mx-auto mt-6 lg:mt-20 space-y-6">
    @if($posts->isEmpty())
        <p class="text-center text-gray-500">Geen posts gevonden.</p>
    @else
        @php($featured = true)
        @foreach($posts as $post)
            @if($loop->first)
                <x-post-card :post="$post" :featured="true" />
            @endif
        @endforeach

        @php($remaining = $posts->skip(1))
        <div class="lg:grid lg:grid-cols-2">
            @foreach($remaining->take(2) as $post)
                <x-post-card :post="$post" :featured="false" />
            @endforeach
        </div>

        <div class="lg:grid lg:grid-cols-3">
            @foreach($remaining->skip(2) as $post)
                <x-post-card :post="$post" :featured="false" />
            @endforeach
        </div>
    @endif
</main>
@endsection
